clc; clear; close all;
[noisySignal, Fs] = audioread('NoisyAudio.wav');

% Time vector for plotting
t = (0:length(noisySignal)-1)/Fs;

% 1. Moving Average Filter Design

N = 125; % Order of Moving Average filter
h1 = ones(1, N) / N; 

% Applying Moving Average Filter using convolution
output1 = conv(noisySignal, h1, 'same');

% 2. Low-Pass FIR Filter Design

Fc = 0.1;
h2 = fir1(100, Fc); % 100th Order Low-Pass FIR Filter

% Applying Low-Pass FIR Filter using convolution
output2 = conv(noisySignal, h2, 'same');

% Ploting all results 

figure;

subplot(3,1,1);
plot(t, noisySignal);
title('Original Noisy Audio Signal');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0 0.0015]);
grid on;

subplot(3,1,2);
plot(t, output1);
title('Filtered Audio - Moving Average');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0 0.0015]);
grid on;

subplot(3,1,3);
plot(t, output2);
title('Filtered Audio - Low-Pass FIR');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0 0.0015]);
grid on;

%Listen to the Audio Files with 2-second pause after each

disp('Playing Original Noisy Signal...');
sound(noisySignal, Fs);
pause(length(noisySignal)/Fs + 2); % 2 sec pause after playing

disp('Playing Moving Average Filtered Output...');
sound(output1, Fs);
pause(length(output1)/Fs + 2); % 2 sec pause after playing

disp('Playing Low-Pass FIR Filtered Output...');
sound(output2, Fs);
pause(length(output2)/Fs + 2); % 2 sec pause after playing
