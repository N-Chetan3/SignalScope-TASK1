clc; clear; close all;               
t = 0:1/1000:1;       


x = sin(2*pi*5*t);      


h = double(t >= 0.5);     

% Convolution using conv
y_conv = conv(x, h);  
% Filtering using filter (FIR)
y_filter = filter(h, 1, x);   

% Multi-dimensional convolution using convn
y_convn = convn(x, h);

% 2D convolution using conv2 
y_conv2 = conv2(x, h);
th=0:1/1000:(length(y_conv)-1)/1000;
% Plotting all results 
figure;

subplot(5,1,1);
plot(t, x, 'b', 'LineWidth', 1.5);
title('Input Signal: 5 Hz Sine Wave');
ylabel('Amplitude');
grid on;

subplot(5,1,2);
plot(t, h, 'k', 'LineWidth', 1.5);
title('Impulse Response: Delayed Unit Step (starts at t=0.5s)');
ylabel('Amplitude');
grid on;

subplot(5,1,3);
plot(th, y_conv, 'r', 'LineWidth', 1.5);
title('Output using conv()');
ylabel('Amplitude');
grid on;

subplot(5,1,4);
plot(t, y_filter, 'g', 'LineWidth', 1.5);
title('Output using filter()');
ylabel('Amplitude');
grid on;

subplot(5,1,5);
plot(th, y_convn, 'm', 'LineWidth', 1.5); hold on;
plot(th, y_conv2, 'c--', 'LineWidth', 1.5);
title('Outputs: convn() (solid magenta) & conv2() (dashed cyan)');
ylabel('Amplitude');
xlabel('Time (s)');
legend('convn','conv2');
grid on;