clc;clear;

cleanImage = imread('a.png'); 
cleanImage = im2double(cleanImage); % Converting to double for processing

% Adding synthetic noise (Gaussian noise)
noisyImage = imnoise(cleanImage, 'gaussian', 0, 0.01); % Mean 0, variance 0.01

% Defining a Gaussian filter kernel
sigma = 1; % Standard deviation 
kernelSize = 5; % Size of the kernel
[x, y] = meshgrid(-floor(kernelSize/2):floor(kernelSize/2), -floor(kernelSize/2):floor(kernelSize/2));
gaussianKernel = exp(-(x.^2 + y.^2) / (2*sigma^2));
gaussianKernel = gaussianKernel / sum(gaussianKernel(:)); % Normalizing the kernel

% Applying the Gaussian filter using imfilter
filteredImage = imfilter(noisyImage, gaussianKernel, 'symmetric');

% Displaying original, noisy, and filtered images
figure;
subplot(1, 3, 1);
imshow(cleanImage);
title('Original Image');

subplot(1, 3, 2);
imshow(noisyImage);
title('Noisy Image');

subplot(1, 3, 3);
imshow(filteredImage);
title('Filtered Image');

% Evaluating the results using PSNR and MSE
mseValue = immse(filteredImage, cleanImage);
psnrValue = psnr(filteredImage, cleanImage);

% Display of evaluation metrics
fprintf('Mean Squared Error (MSE): %.4f\n', mseValue);
fprintf('Peak Signal-to-Noise Ratio (PSNR): %.4f dB\n', psnrValue);